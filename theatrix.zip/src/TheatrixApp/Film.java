/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TheatrixApp;

/**
 *
 * @author Tuf Gaming
 */
public interface Film {
    public void setJudul(String judul);
    public void setSinopsis(String sinopsis);
    public void setProduser(String produser);
    public void setSutradara(String sutradara);
    public String getJudul();
    public String getSinopsis();
    public String getProduser();
    public String getSutradara();
    
    
}
